<?php
require_once($_SERVER['DOCUMENT_ROOT']."/core/head.php");
?>
<h1><?=$sitename?> Landing Page</h1>
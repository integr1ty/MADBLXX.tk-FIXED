<?php
require_once($_SERVER['DOCUMENT_ROOT']."/core/head.php");
?>
<div id="Body">
<br>
<br>
<br>
<br>
<h2 style="text-align:center">The item you requested does not exist</h2>
<br>
<br>
<br>
<br>
				</div>
<?php
require_once($_SERVER['DOCUMENT_ROOT']."/core/footer.php");
?>
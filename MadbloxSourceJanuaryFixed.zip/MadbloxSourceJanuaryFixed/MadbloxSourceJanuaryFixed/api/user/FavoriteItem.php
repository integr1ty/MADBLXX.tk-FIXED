<?php
require_once($_SERVER['DOCUMENT_ROOT']."/core/database.php");
?>
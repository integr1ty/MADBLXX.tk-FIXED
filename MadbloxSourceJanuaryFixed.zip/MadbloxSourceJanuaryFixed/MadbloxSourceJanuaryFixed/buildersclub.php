<?php

require_once 'core/database.php';
include 'core/head.php';

$title = "Builders Club - " . $sitename;


?>
<div style='margin: 150px auto 150px auto; width: 500px; border: black thin solid; padding: 22px;'><strong><p> We are working on functional builders club page!</p></strong></div>
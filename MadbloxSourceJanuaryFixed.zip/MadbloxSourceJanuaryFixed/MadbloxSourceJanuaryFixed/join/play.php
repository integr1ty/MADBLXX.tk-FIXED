dofile("http://madblox.com/join/JoinServer.php?<?php echo $_SERVER["QUERY_STRING"]; ?>&")
dofile("http://madblox.com/join/character.php?<?php echo $_SERVER["QUERY_STRING"]; ?>&")
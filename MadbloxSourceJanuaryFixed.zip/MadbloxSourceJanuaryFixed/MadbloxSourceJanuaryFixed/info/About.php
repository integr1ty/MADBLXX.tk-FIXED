<?php
require_once($_SERVER['DOCUMENT_ROOT'].'/core/head.php');
?>
<div id="Body">
<h2>About Us</h2>
<big>
	<p><?=$sitename?> is a revival based on the year 2009. It is currenty one of the best 2009 revivals that you can see in the Old Roblox Community.</p>
	<p>Owned by NiceYomi, All thanks to the community for making this revival big, its all because of you guys, thank you so much.</p>
	<p>Special thanks to:</p>
	<ul>
		<li>Big Dude</li>
		<li>crystallized</li>
		<li>met</li>
		<li>Thugshaker</li>
		<li>nolanwhy</li>
		<li>9caseyu</li>
		<li>catzlol</li>
		<li>job</li>
		<li>rcc.service</li>
		<li>CryptoPath</li>
		<li>miky mouze</li>
		<li>Soul</li>
		<li>lucky</li>
		<li>cyb3r</li>
		<li>You</li>
	</ul>
	<p>Thank you everyone! <?=$sitename?> wouldn't be like this if y'all werent here</p>
	
	
</big>
				</div>
				<?php
require_once($_SERVER['DOCUMENT_ROOT'].'/core/footer.php');
?>
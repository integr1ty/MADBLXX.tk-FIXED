<?php
require_once($_SERVER['DOCUMENT_ROOT'].'/core/head.php');

if($loggedin != "yes"){
    header("location: ../Login/Default.aspx");
}

if ($_SERVER["REQUEST_METHOD"] == 'POST') {
    if ($_POST["Blurb"]) {
        $desiredblurb = htmlspecialchars($_POST["Blurb"]);

        $stmt = $db->prepare("UPDATE users SET blurb = :blurb WHERE id = :id");
        $stmt->execute(['blurb' => $desiredblurb, 'id' => $_USER['id']]);
    }

}
?>
<style>
#EditProfileContainer {
    background-color: #eeeeee;
    border: 1px solid #000;
    color: #555;
    margin: 0 auto;
    width: 620px;
}
fieldset {
    font-size: 1.2em;
    margin: 15px 0 0 0;
}
</style>
<div id="Body">
<form method="post" action="<?=$_SERVER['PHP_SELF']?>">
	<div id="EditProfileContainer">
		<h2>Edit Profile</h2>
		<div id="ResetPassword">
			<fieldset title="Reset your password">
				<legend>Change your password</legend>
				<div class="Suggestion">Click the button below to change your password.</div>
				<div class="ResetPasswordRow">
					&nbsp;<a href="/Login/ChangePassword.aspx">Change Password</a>
		    	</div>
			</fieldset>
		</div>
		<div id="EnterEmail">
			<fieldset title="Update Your Email Address">
				<legend>Update Your Email Address</legend>
				<div class="Suggestion">Click the button below to update your email address.</div>
				<div class="Validators">
									</div>
				<div class="ResetPasswordRow">
					&nbsp;<a href="Email.aspx">Update Email</a>
							    	</div>
		    	<!--p><b>Email Verified</b></p-->			</fieldset>
		</div>
		<div id="Blurb">
			<fieldset title="Update your personal blurb">
				<legend>Update your personal blurb</legend>
				<div class="Suggestion">Describe yourself here (max. 1000 characters). Make sure not to provide any details that can be used to identify you outside <?=$sitename?>.</div>
				<div class="Suggestion" style="color:RED"></div>
				<div class="BlurbRow">
					<textarea name="Blurb" rows="12" cols="20" id="Blurb" class="MultilineTextBox"></textarea>
				</div>
			</fieldset>
		</div>
				<div class="Buttons">
			<input name="Update" id="Update" tabindex="4" class="Button" type="submit" value="Update">&nbsp;<a id="Cancel" tabindex="5" class="Button" href="/User.aspx">Cancel</a>
		</div>
	</div>
</form>
<style>
				#EditProfileContainer {
    background-color: #eeeeee;
    border: 1px solid #000;
    color: #555;
    margin: 0 auto;
    width: 620px;
}
#EditProfileContainer #AgeGroup, #EditProfileContainer #ChatMode, #EditProfileContainer #PrivacyMode, #EditProfileContainer #EnterEmail, #EditProfileContainer #ResetPassword, #EditProfileContainer #Blurb {
    margin: 0 auto;
    width: 60%;
}
				</style>
				</div>
				<?php require_once($_SERVER['DOCUMENT_ROOT'].'/core/footer.php'); ?>